#accessing s3 bucket

bucket_name = 'mysensordatainjson'
file_key = 'sample_data.json'

s3 = boto3.client('s3')

with open('sample_data.json','w') as file:
    s3.download_fileobj(bucket_name, file_key, file)

with open('sample_data.json','r') as file:
    data = json.load(file)

#loading data dynamodb
dynamodb = boto3.resource('dynamodb')
table_name = 'sensor_data_raw'
table = dynamodb.Table(table_name)

def has_p1_p2_data(record):
    for sdv in record.get('sensordatavalues',[]):
        if sdv.get('value_type') in ['P1','P2']:
            return True
    return False

def extract_fields(record):
    return {
    'id' : record.get('id'),
    'latitude' : record.get('location',{}).get('latitude'),
    'longitude' : record.get('location',{}).get('longitude'),
    'altitude' : record.get('location',{}).get('altitude'),
    'timestamp' : record.get('timestamp'),
    'P2.5' : next((sdv['value'] for sdv in record.get('sensordatavalues', []) if sdv['value_type'] == 'P1'), None),
    'P10' : next((sdv['value'] for sdv in record.get('sensordatavalues', []) if sdv['value_type'] == 'P2'), None)
    }

for record in data:
    if has_p1_p2_data(record):
        fields = extract_fields(record)
        table.put_item(Item = fields)
        print(f"Inserted record with id: {fields.get('id')}")

print('Data insertion complete')