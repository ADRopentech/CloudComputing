import socket
import threading
import json
import boto3
import os
import csv

#server global variables

HEADER = 64
PORT = 12000
SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER,PORT)
FORMAT = 'utf-8'
DISCONNECT_MESSAGE = "!DISCONNECT"

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)

#connect to dynamodb

dynamodb = boto3.resource('dynamodb', region_name = 'us-east-1')
table = dynamodb.Table('air_quality_data')

#create csv
def write_to_csv(data, filename):
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = data[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for row in data:
            writer.writerow(row)

#send csv
def send_csv(conn, filename):
    with open(filename, 'rb') as file:
        file_data = file.read()
        #message = file_data.encode(FORMAT)
        message_length = len(file_data)
        send_length = str(message_length).encode(FORMAT)
        send_length += b' '*(HEADER - len(send_length))
        conn.send(send_length)
        conn.send(file_data)

#server functions

def handle_client(conn, addr):
    print(f"[NEW CONNECTION]{addr} connected.")

    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(FORMAT)
            if msg == DISCONNECT_MESSAGE:
                connected = False
                print(f"[{addr}] Disconnecting...")
            else:
                retrieve = table.get_item(
                    Key={
                        "id": int(msg)
                    }
                )
                item = retrieve.get('Item')
                if item:
                    data = [item]
                    filename = f"data_{msg}.csv"
                    
                    # Write data to CSV
                    write_to_csv(data, filename)
                    
                    # Send the CSV file to the client
                    send_csv(conn, filename)

                    # Remove the CSV file after sending
                    os.remove(filename)
                    
                else:
                    item_str = "Item not found"
                    print(f"[{addr}] {msg}")
                    conn.send(item_str.encode())

    
    conn.close()

def start():
    server.listen()
    print(f"Server is listening on {SERVER}")
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target = handle_client, args = (conn,addr))
        thread.start()
        print(f"[ACTIVE CONNECTIONS] {threading.activeCount()-1}")

print('[STARTING] server is starting')
start()